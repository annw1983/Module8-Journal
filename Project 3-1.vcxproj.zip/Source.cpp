#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{

    char choice;
    time_t t = time(0);
    struct tm* now = localtime(&t);
    int hour = now->tm_hour;
    int min = now->tm_min;
    int sec = now->tm_sec;

    do
    {
        cout << "Please select one of the following options: \n";
        cout << "1 - Add One Hour\n";
        cout << "2 - Add One Minute\n";
        cout << "3 - Add One Second\n";
        cout << "4 - Exit\n";

        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case '1':
            hour++;
            if (hour > 23)
                hour = 0;
            break;
        case '2':
            min++;
            if (min > 59)
            {
                min = 0;
                hour++;
                if (hour > 23)
                    hour = 0;
            }
            break;
        case '3':
            sec++;
            if (sec > 59)
            {
                sec = 0;
                min++;
                if (min > 59)
                {
                    min = 0;
                    hour++;
                    if (hour > 23)
                        hour = 0;
                }
            }
            break;
        case '4':
            cout << "The End!\n";
            system("pause");
            break;
        default:
            cout << "Invalid choice!\n";
            system("pause");
            break;
        }

        if (choice >= '1' && choice <= '3')
        {
            cout << "12-Hour Clock\n";
            if (hour < 12)
                cout << hour << ":" << min << ":" << sec << " AM\n";
            else
            {
                cout << hour - 12 << ":" << min << ":" << sec << " PM\n";
            }

            cout << "24-Hour Clock\n";
            cout << hour << ":" << min << ":" << sec << endl;
            system("pause");
            system("cls");
        }
    } while (choice >= '1' && choice <= '3');
    return 0;
}